Sent by an Olol participant, link to the original https://drive.google.com/drive/folders/1LkJ85WhvyhYk6WmqsuG-v-sFNjMWdnZ4
